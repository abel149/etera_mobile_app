@extends('layouts.business-owner')
@section('content')
<style type="text/css">
.card-stamp {
    position: absolute;
    top: 3rem;
    right: 50%;
    width: calc(var(7rem)* 1);
    height: calc(var(7rem)* 1);
    max-height: 100%;
    border-top-right-radius: 4px;
    opacity: .3;
    overflow: hidden;
    pointer-events: none;
    z-index:5;
}

.card-stamp-icon {
    background: rgba(255, 255, 255, 0.5)
    color: rgba(0, 255, 255, 0.5)
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 100rem;
    width: calc(var(7rem)* 1);
    height: calc(var(7rem)* 1);
    position: relative;
    top: calc(var(7rem)* -.25);
    right: calc(var(7rem)* -.25);
    font-size: calc(var(7rem)* .75);
    transform: rotate(10deg);
}

.profile-pic.stamp-image {
    width: 200px;
    /* adjust as needed for 'smaller' */
    height: 200px;
    border-radius: 50%;
    /* makes it a perfect circle */
    object-fit: cover;
    /* ensures image covers the circle */
    border: 2px solid #ccc;
    /* optional, for a clean border */
}

table {
    width: 100%;
    border-collapse: collapse;
}

th, td {
    padding: 8px;
    text-align: left;
    border-bottom: 1px solid #ddd;
}
.invoice-card {
    border-radius: 12px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
.invoice-header {
    background-color: #1976d2;
    color: white;
    padding: 24px;
    border-top-left-radius: 12px;
    border-top-right-radius: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.invoice-title {
    font-size: 2.25rem;
    font-weight: 700;
    margin: 0;
}
.invoice-details {
    padding: 24px;
}
.invoice-details p {
    margin-bottom: 8px;
    font-size: 1rem;
}
.invoice-details strong {
    font-weight: 600;
    color: #333;
}
.table-container {
    overflow-x: auto;
}
.invoice-table th,
.invoice-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #e0e0e0;
}
.invoice-table thead th {
    background-color: #f5f5f5;
    font-weight: 600;
}
.invoice-summary {
    padding: 24px;
    border-bottom-left-radius: 12px;
    border-bottom-right-radius: 12px;
    background-color: #f9f9f9;
}
.invoice-summary-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 8px 0;
    font-size: 1rem;
}
.invoice-summary-row strong {
    font-weight: 600;
}
.grand-total {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1976d2;
    border-top: 2px solid #1976d2;
    padding-top: 16px;
    margin-top: 16px;
}
.download-button {
    background-color: #1976d2;
    color: white;
    border-radius: 20px;
    padding: 10px 24px;
    font-size: 1rem;
    transition: background-color 0.3s;
}
.download-button:hover {
    background-color: #1565c0;
}
.center-content {
    display: flex;
    justify-content: center;
    align-items: center;
}
.company-stamp {
    position: absolute;
    bottom: 60px;
    left: 10rem;
    width: 200px;
    height:200px;
    opacity: 0.7;
    transform: rotate(10deg);
    pointer-events: none;
}
.stamp {
    position: absolute;
    bottom: 24px;
    right: 24px;
    width: 120px;
    height: 120px;
    opacity: 0.7;
    transform: rotate(10deg);
    pointer-events: none;
}
@media print {
    .d-print-none {
        display: none !important;
    }
}
</style>
<div class="card">
	<div class="card-body">
        {{-- Voice Note Section --}}
        @if($proforma->voice_note_path)
            <div class="row mb-4">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0"><i class="bx bx-volume-full me-2"></i>Voice Note</h6>
                        </div>
                        <div class="card-body">
                            <audio controls style="width: 100%;">
                                <source src="{{ asset('storage/' . $proforma->voice_note_path) }}" type="audio/webm">
                                <source src="{{ asset('storage/' . $proforma->voice_note_path) }}" type="audio/mp3">
                                Your browser does not support the audio element.
                            </audio>
                        </div>
                    </div>
                </div>
            </div>
        @endif
		<div class="row">
            @if($proforma->has('applications'))
                <div class="col-12 col-md-6 mx-auto">
                    <h4 class="mb-3 steper-title text-center">Spare Part Shops</h4>
                    @foreach($proforma->applications as $application)
                        @if($application->applicationBy->role == 'shop')
                            <div class="col-lg-12 job-listing">
                                <div class="card shadow">
                                    <div class="card-stamp">
                                        @if($application->applicationBy->stamp_image)
                                            <img class="profile-pic stamp-image"
                                                 src="{{ asset('storage/stamps/' . basename($application->applicationBy->stamp_image)) }}"
                                                 alt="Stamp" />
                                        @else
                                            <img class="profile-pic stamp-image"
                                                 src="{{ asset('assets/images/stamp.png') }}"
                                                 alt="No Stamp Here" />
                                        @endif
                                    </div>
                                    <div class="card-header">
                                        <div class="d-flex align-items-center">
                                            <div class="">
                                                <img src="{{ asset('assets/images/avatars/avatar-9.jpg') }}" class="rounded-circle" width="40" height="40" alt="">
                                            </div>
                                            <div class="ms-2">
                                                <a href="javascript:;" data-bs-toggle="modal" data-bs-target="#details">
                                                    <h6 class="mb-0 font-17 job-listing-title">{{ $application->applicationBy->name }}</h6>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-body pt-3 px-4 pb-0">
                                        <p class="mb-1">
                                            <b>Phone Number:</b>
                                            <span class="text-secondary font-16">{{ $application->applicationBy->phone_number }}</span>
                                            <b>Store ID:</b>
                                            <span class="text-secondary font-16">{{ $application->applicationBy->store_id }}</span>
                                            <b>Tin #:</b>
                                            <span class="text-secondary font-16">{{ $application->applicationBy->tin_number }}</span><br>
                                            <b>Location:</b>
                                            <span class="text-secondary font-16">{{ $application->applicationBy->location }}</span>
                                        </p>
                                        </p>
                                        <p class="mb-1">
                                            
                                        <div class="invoice mb-1" style="overflow-y: hidden; overflow-x: auto; white-space: nowrap;">
                                            <table style="font-size: 10px; border-collapse: collapse; width: 100%;">
                                                <thead>
                                                    <tr>
                                                        <th style="text-align: left; padding: 4px;">No</th>
                                                        <th style="text-align: left; padding: 4px;">Part Name and Part Number</th>
                                                        <th style="text-align: left; padding: 4px;">Component</th>
                                                        <th style="text-align: left; padding: 4px;">Condition</th>
                                                        <th style="text-align: left; padding: 4px;">Grade</th>
                                                        <th style="text-align: left; padding: 4px;">Country</th>
                                                        <th style="text-align: left; padding: 4px;">Qty</th>
                                                        <th style="text-align: left; padding: 4px;">Unit Price</th>
                                                        <th style="text-align: left; padding: 4px;">Total Price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach($proforma->parts as $part)
                                                        @php
                                                            $partPrice = $application->prices->where('car_part_id', $part->id)->first();
                                                            if (!$partPrice) {
                                                                $partPrice = $application->prices->values()->get($loop->index);
                                                            }
                                                        @endphp
                                                        <tr>
                                                            <td>{{ $loop->index + 1 }}</td>
                                                            <td>{{ $part->number }}</td>
                                                            <td>{{ $part->component ?? 'N/A' }}</td>
                                                            <td>{{ $part->condition ?? 'N/A' }}</td>
                                                            <td>{{ $part->grade }}</td>
                                                            <td>{{ $part->country }}</td>
                                                            <td>{{ $part->quantity }}</td>
                                                            @if($partPrice)
                                                                <td>{{ number_format($partPrice->unit_price, 2) }} ETB</td>
                                                                <td>{{ number_format($partPrice->part_total ?? ($partPrice->unit_price * ($part->quantity ?? 1)), 2) }} ETB</td>
                                                            @else
                                                                <td>0.00 ETB</td>
                                                                <td>0.00 ETB</td>
                                                            @endif
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <td colspan="7"></td>
                                                        <td>SUBTOTAL</td>
                                                        <td>
                                                            @php
                                                                $discountPct = (float)($application->discount ?? 0);
                                                                $subtotalParts = (float) $application->prices->sum('part_total');
                                                                $usingParts = $subtotalParts > 0;
                                                                $subtotal = $usingParts ? $subtotalParts : (float) $application->amount;
                                                                $discountAmt = $usingParts ? (($subtotal * $discountPct) / 100) : 0.0;
                                                                $netTotal = $usingParts ? ($subtotal - $discountAmt) : (float) $application->amount;
                                                            @endphp
                                                            {{ number_format($subtotal, 2) }} ETB
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="7"></td>
                                                        <td>DISCOUNT</td>
                                                        <td>{{ number_format($discountAmt, 2) }} ETB ({{ $discountPct }}%)</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="7"></td>
                                                        <td>NET TOTAL</td>
                                                        <td>{{ number_format($netTotal, 2) }} ETB</td>
                                                    </tr>
                                                    <tr>
                                                        <td colspan="7"></td>
                                                        <td>GRAND TOTAL</td>
                                                        <td>{{ number_format($netTotal, 2) }} ETB</td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                            <p style="font-size: 9px; margin-top: 4px;">
                                                <strong class="text-danger">NOTE:</strong> All prices not including VAT
                                            </p>
                                        </div>
                                    </div>
                                    <div class="card-footer text-end">
                                        <button class="btn btn-outline-primary" onclick="openPrintPage(this)">Select</button>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endforeach
                </div>
            @else
                <div class="col-md-6 col-12 mx-auto">
                    <p class="text-center font-17">No Proforma Application found yet!</p>
                </div>
            @endif
        </div>
        <a href="javascript:void();" class="btn btn-primary rounded-pill px-4">Submit</a>
    </div>
</div>

<div class="modal fade" id="details" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">User Name</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-lg-6">
                        <label for="input1" class="form-label">Name</label>
                        <input name="name" type="text" class="form-control" id="input1" placeholder="Company Name">
                    </div>
                    <div class="col-lg-6">
                        <label for="input7" class="form-label">Email</label>
                        <input name="email" type="email" class="form-control" id="input7" placeholder="Email">
                    </div>
                    <div class="col-lg-6">
                        <label for="input2" class="form-label">Phone Number</label>
                        <input name="phone_number" type="text" class="form-control" id="input2" placeholder="251...">
                    </div>
                    <div class="col-lg-6">
                        <label for="input3" class="form-label">Tin #</label>
                        <input name="tin_number" type="text" class="form-control" id="input3" placeholder="Tin #">
                    </div>
                    <div class="col-lg-6">
                        <label for="input4" class="form-label">Location / Address</label>
                        <input name="location" type="text" class="form-control" id="input4" placeholder="Location">
                    </div>
                    <div class="col-12 col-lg-6">
                        @php
                            $brands = App\Models\Brand::orderBy('name', 'asc')->get();
                            $parts = App\Models\CarPart::orderBy('name', 'asc')->get();
                        @endphp
                        <label for="InputCountry" class="form-label">Brand</label>
                        <select name="brand_id" id="InputCountry">
                            @foreach ($brands as $brand)
                                <option {{ old('brand_id') == $brand->id ? 'selected' : '' }} value="{{ $brand->id }}">{{ $brand->name }}</option>
                            @endforeach
                        </select>
                        @error('brand_id')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="col-12 col-lg-6">
                        <label for="InputCountry" class="form-label">Year</label>
                        <select name="year" id="InputCountry">
                            @for($i = 1980; $i <= date('Y'); $i++)
                                <option value="{{$i}}" {{ old('year') == $i ? 'selected' : '' }}>{{$i}}</option>
                            @endfor
                        </select>
                        @error('year')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="col-12 col-lg-4">
                        <label for="inputName1" class="form-label">Grade</label>
                        <select name="parts[grade][]" id="inputName1">
                            <option value="1st Grade" {{ old('parts.grade.*') == '1st Grade' ? 'selected' : '' }}>1st Grade</option>
                            <option value="2nd Grade" {{ old('parts.grade.*') == '2nd Grade' ? 'selected' : '' }}>2nd Grade</option>
                            <option value="3rd Grade" {{ old('parts.grade.*') == '3rd Grade' ? 'selected' : '' }}>3rd Grade</option>
                        </select>
                        @error('parts.grade.*')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="col-12 col-lg-2">
                        <label for="condition" class="form-label">Component</label>
                        <select name="parts[condition][]" id="condition" required>
                            <option value="">Select Component</option>
                            <option value="Body Parts" {{ old('parts.condition.*') == 'Body Parts' ? 'selected' : '' }}>Body Parts</option>
                            <option value="Mechanical Parts" {{ old('parts.condition.*') == 'Mechanical Parts' ? 'selected' : '' }}>Mechanical Parts</option>
                        </select>
                        @error('parts.condition.*')
                            <span class="text-danger">{{ $message }}</span>
                        @enderror
                    </div>
                    <div class="col-lg-8">
                        <label for="input6" class="form-label">Business License Image</label>
                        <div class="text-center"><img src="{{asset('assets/images/avatars/avatar-1.png')}}"></div>
                    </div>
                    <div class="col-lg-4">
                        <label for="input6" class="form-label">Stamp Image</label>
                        <div class="text-center" style="max-width: 200px; min-width: 200px"><img style="max-width: 300px;" src="{{asset('assets/images/original.png')}}"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary radius-30" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

@include('components.proforma-media', ['proforma' => $proforma])



{{-- Invoice Link --}}
@if($proforma->proformaInvoice && $proforma->proformaInvoice->sku)
    <div class="text-center mt-4 mb-3">
        <a href="{{ url('/transaction/' . $proforma->proformaInvoice->sku) }}" class="btn btn-primary rounded-pill px-5 py-2" target="_blank">
            <i class="fas fa-file-invoice me-2"></i> View Invoice
        </a>
    </div>
@endif

<script>
	function openPrintPage(button) {
		let card = button.closest('.job-listing, .card'); // Support both structures

		// This part is for the Spare Part Shop Invoice
		let isSparePartInvoice = card.querySelector(".job-listing-title, h6.mb-0.font-17");
		if (isSparePartInvoice) {
			let storeId = card.querySelector(".text-secondary:nth-of-type(2)")?.textContent.trim() || "N/A";
			let tinNumber = card.querySelector(".text-secondary:nth-of-type(3)")?.textContent.trim() || "N/A";
			let location = card.querySelector(".text-secondary:nth-of-type(4)")?.textContent.trim() || "N/A";
			let shopName = card.querySelector(".job-listing-title, h6.mb-0.font-17")?.textContent.trim() || "N/A";
			let phoneNumber = card.querySelector("p span.text-secondary.font-16:nth-of-type(1)")?.textContent.trim() || "N/A";
			let stampImage = card.querySelector(".card-stamp img")?.src || "{{ asset('assets/images/stamp.png') }}";

			let table = card.querySelector("table");
			let rows = table?.querySelectorAll("tbody tr") || [];
			let partsData = [];

			rows.forEach((row, index) => {
				let cells = row.querySelectorAll("td");
				if (cells.length >= 8) {
					partsData.push({
						no: index + 1,
						partNumber: cells[1].textContent.trim(),
						component: cells[2].textContent.trim(),
						condition: cells[3].textContent.trim(),
						grade: cells[4].textContent.trim(),
						country: cells[5].textContent.trim(),
						quantity: cells[6].textContent.trim(),
						unitPrice: cells[7].textContent.trim(),
						total: cells[8].textContent.trim()
					});
				}
			});

			function parseETB(value) {
				return parseFloat(value.replace(/[^0-9.-]+/g, "")) || 0;
			}
            function formatETB(num) {
                return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " ETB";
            }

			let subtotal = partsData.reduce((sum, p) => sum + parseETB(p.total), 0);
			let discountPct = parseFloat(card.dataset?.discount) || 0;
			let discountAmt = (subtotal * discountPct) / 100;
			let netTotal = subtotal - discountAmt;

			let printWindow = window.open('', '_blank');
			printWindow.document.write(`
				<!DOCTYPE html>
				<html lang="en">
				<head>
					<meta charset="utf-8" />
					<meta http-equiv="X-UA-Compatible" content="IE=edge">
					<meta name="viewport" content="width=device-width, initial-scale=1">
					<title>ETERA - Invoice</title>
					<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700' type='text/css'>
					<link rel="stylesheet" href="{{ asset('assets/invoice/vendor/bootstrap/css/bootstrap.min.css') }}"/>
					<link rel="stylesheet" href="{{ asset('assets/invoice/vendor/font-awesome/css/all.min.css') }}"/>
					<link rel="stylesheet" href="{{ asset('assets/invoice/css/stylesheet.css') }}"/>
					<style>
						.table th, .table td { padding: 8px; }
						.text-end { text-align: right; }
						.company-stamp {
						position: absolute;
						bottom: 160px;
						left: 4px;
						width: 300px;
						height:300px;
						opacity: 0.7;
						transform: rotate(10deg);
						pointer-events: none;
						}
						.stamp-image {
							width: 200px;
							height: 200px;
							border-radius: 50%;
							object-fit: cover;
							border: 2px solid #ccc;
						}
						.card-stamp {
							position: absolute;
							top: 3rem;
							right: 50%;
							opacity: .3;
							z-index:5;
						}
						.invoice-container { position: relative; }
					</style>
				</head>
				<body>
					<div class="container-fluid invoice-container">
						<header>
							<div class="row align-items-center gy-3">
								<div class="col-sm-7 text-center text-sm-start">
								<h3 class="text-7 mb-0">Online Proforma</h3>
			
								<div class="col-sm-5 text-center text-sm-end">
									<h4 class="text-7 mb-0">Invoice</h4>
								</div>
							</div>
							<hr>
						</header>

						<main>
							<div class="row">
								<div class="col-sm-6"><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>
								<div class="col-sm-6 text-sm-end"><strong>Invoice No:</strong> ${Math.floor(Math.random() * 100000)}</div>
							</div>
							<hr>

							<div class="row gy-3 align-items-start">
								<div class="col-sm-6">
									<p class="mb-1"><strong>Store ID:</strong> ${storeId}</p>
									<p class="mb-1"><strong>Shop Name:</strong> ${shopName}</p>
									<p class="mb-1"><strong>Tin #:</strong> ${tinNumber}</p>
									<p class="mb-1"><strong>Location:</strong> ${location}</p>
									<p class="mb-1"><strong>Phone:</strong> ${phoneNumber}</p>
								</div>
								<div class="col-sm-6 text-sm-end">
									<strong>Author:</strong>
									<address>
										ETERA<br />
										portal.eteraet.com<br />
										Addis Ababa, Ethiopia
									</address>
								</div>
							</div>

							<div class="table-responsive mt-4">
								<table class="table border">
									<thead>
										<tr>
											<th>No</th>
											<th>Part Name & Number</th>
											<th>Component</th>
											<th>Condition</th>
											<th>Grade</th>
											<th>Country</th>
											<th>Qty</th>
											<th>Unit Price</th>
											<th>Total</th>
										</tr>
									</thead>
									<tbody>
										${partsData.map(part => `
											<tr>
												<td>${part.no}</td>
												<td>${part.partNumber}</td>
												<td>${part.component}</td>
												<td>${part.condition}</td>
												<td>${part.grade}</td>
												<td>${part.country}</td>
												<td>${part.quantity}</td>
												<td>${part.unitPrice}</td>
												<td>${part.total}</td>
											</tr>
										`).join('')}
									</tbody>
									<tfoot>
										<tr>
											<td colspan="7" class="text-end"><strong>SUBTOTAL:</strong></td>
											<td class="text-end">${formatETB(subtotal)}</td>
										</tr>
										<tr>
											<td colspan="7" class="text-end"><strong>DISCOUNT:</strong></td>
											<td class="text-end">${formatETB(discountAmt)} (${discountPct}%)</td>
										</tr>
										<tr>
											<td colspan="7" class="text-end"><strong>NET TOTAL:</strong></td>
											<td class="text-end">${formatETB(netTotal)}</td>
										</tr>
										<tr style="background-color: #e3f2fd; font-weight: bold; border-top: 2px solid #1976d2;">
											<td colspan="7" class="text-end"><strong>GRAND TOTAL:</strong></td>
											<td class="text-end" style="color: #1976d2; font-size: 1.1em;">${formatETB(netTotal)}</td>
										</tr>
									</tfoot>
								</table>
							</div>

							<p class="text-danger mt-4"><strong>NOTE:</strong> All prices not including VAT</p>

							<div class="card-stamp">
								<img class="stamp-image" src="${stampImage}" alt="Stamp" />
							</div>
						</main>

						<footer class="text-center mt-4">
							<p><strong>NOTE:</strong> Price is NOT including 15% VAT.</p>
							<div class="btn-group btn-group-sm d-print-none">
								<a href="javascript:window.print()" class="btn btn-light border text-black-50 shadow-none">
									<i class="fa fa-print"></i> Print & Download
								</a>
							</div>
						</footer>
					</div>
				</body>
				</html>
			`);
			printWindow.document.close();
		} else {
			// This part is for the ETERA Receipt
			let customerName = "{{ $proforma->customer_name ?? 'N/A' }}";
			let customerPhone = "{{ $proforma->customer_phone_number ?? 'N/A' }}";
			let createdAt = "{{ $proforma->proformaInvoice->created_at->format('M d, Y') }}";
			let brand = "{{ $proforma->brand->name ?? 'N/A' }}";
			let year = "{{ $proforma->year ?? 'N/A' }}";
			let description = "{{ $proforma->description ?? 'N/A' }}";

			let printWindow = window.open('', '_blank');
			printWindow.document.write(`
				<!DOCTYPE html>
				<html lang="en">
				<head>
					<meta charset="utf-8" />
					<meta http-equiv="X-UA-Compatible" content="IE=edge">
					<meta name="viewport" content="width=device-width, initial-scale=1">
					<title>ETERA - Receipt</title>
					<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700' type='text/css'>
					<link rel="stylesheet" href="{{ asset('assets/invoice/vendor/bootstrap/css/bootstrap.min.css') }}"/>
					<link rel="stylesheet" href="{{ asset('assets/invoice/vendor/font-awesome/css/all.min.css') }}"/>
					<link rel="stylesheet" href="{{ asset('assets/invoice/css/stylesheet.css') }}"/>
					<style>
						.table th, .table td { padding: 8px; }
						.text-end { text-align: right; }
						.stamp-image {
							width: 200px;
							height: 200px;
							border-radius: 50%;
							object-fit: cover;
							border: 2px solid #ccc;
						}
						.card-stamp {
							position: absolute;
							top: 3rem;
							right: 50%;
							opacity: .3;
							z-index:5;
						}
						
						.company-stamp {
							position: absolute;
							bottom: 0;
							right: 10rem;
							width: 200px;
							height:200px;
							opacity: 0.7;
							transform: rotate(10deg);
							pointer-events: none;
							z-index:5;
						}
						.invoice-container { position: relative; }
					</style>
				</head>
				<body>
					<div class="container-fluid invoice-container">
						<header>
							<div class="row align-items-center gy-3">
								<div class="col-sm-7 text-center text-sm-start">
									<img id="logo" src="{{ asset('assets/invoice/images/transparent.png') }}" height="70" width="200" alt="ETERA" />
								</div>
								<div class="col-sm-5 text-center text-sm-end">
									<h4 class="text-7 mb-0">ETERA - Receipt<br>(Official Hard copy is availabe at the office)</h4>
								</div>
							</div>
							<hr>
						</header>

						<main>
							<div class="row gy-3 align-items-start">
								<div class="col-sm-6">
									<p class="mb-1"><strong>ETERA:</strong></p>
									<p class="mb-1"><strong>Phone:</strong> 011-470-7566</p>
									<p class="mb-1"><strong>TIN:</strong> 0094205503</p>
									<p class="mb-1"><strong>Date:</strong> ${createdAt}</p>
								</div>
								<div class="col-sm-6 text-sm-end">
									<strong>Customer:</strong> ${customerName}<br>
									<strong>Phone:</strong> ${customerPhone}
								</div>
							</div>

							<div class="table-responsive mt-4">
								<table class="table border">
									<thead>
										<tr>
											<th>Item</th>
											<th class="text-end">Quantity</th>
											<th class="text-end">Price</th>
										</tr>
									</thead>
									<tbody>
										@if($proforma->proformaInvoice->type === 'regular')
											<tr>
												<td>Proforma Service</td>
												<td class="text-end">{{ $proforma->proformaInvoice->requested_count }}</td>
												<td class="text-end">{{ number_format($proforma->proformaInvoice->unit_price, 2) }} ETB</td>
											</tr>
										@else
											<tr>
												<td>Et-era Chereta Service (Hourly)</td>
												<td class="text-end">{{ $proforma->proformaInvoice->hours }} Hours</td>
												<td class="text-end">{{ number_format($proforma->proformaInvoice->hourly_price, 2) }} ETB</td>
												<td class="text-end">{{ number_format($proforma->proformaInvoice->hours * $proforma->proformaInvoice->hourly_price, 2) }} ETB</td>
											</tr>
										@endif
									</tbody>
									<tfoot>
									    <tr style="background-color: #e3f2fd; font-weight: bold; border-top: 2px solid #1976d2;">
											<td colspan="2" class="text-end"><strong></strong></td>
											<td class="text-end" style="color: #1976d2; font-size: 1.1em;"></td>
										</tr>
										<tr style="background-color: #e3f2fd; font-weight: bold; border-top: 2px solid #1976d2;">
											<td colspan="2" class="text-end"><strong>VAT ({{ number_format($proforma->proformaInvoice->vat_rate, 2) }}%):</strong></td>
											<td class="text-end" style="color: #1976d2; font-size: 1.1em;">{{ number_format($proforma->proformaInvoice->vat_amount, 2) }} ETB</td>
										</tr>
										<tr style="background-color: #e3f2fd; font-weight: bold; border-top: 2px solid #1976d2;">
											<td colspan="2" class="text-end"><strong>GRAND TOTAL:</strong></td>
											<td class="text-end" style="color: #1976d2; font-size: 1.1em;">{{ number_format($proforma->proformaInvoice->total_amount, 2) }} ETB</td>
										</tr>
									</tfoot>
								</table>
								 <img src="{{ asset('assets/invoice/images/stamp.png') }}" class="company-stamp" alt="Stamp">
							</div>
						</main>

						<footer class="text-center mt-4">
							<div class="btn-group btn-group-sm d-print-none">
								<a href="javascript:window.print()" class="btn btn-light border text-black-50 shadow-none">
									<i class="fa fa-print"></i> Print & Download
								</a>
							</div>
						</footer>
					</div>
				</body>
				</html>
			`);
			printWindow.document.close();
		}
	}
</script>
@endsection