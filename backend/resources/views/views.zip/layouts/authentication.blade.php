<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <!-- Favicon -->
    <link rel="icon" href="{{ asset('favicon.ico') }}" type="image/x-icon"/>
    <link rel="icon" href="{{ asset('assets/images/transparent.jpg') }}" type="image/jpeg" />

    <!-- ETERA Modern Design System -->
    <link href="{{ asset('assets/css/etera-modern.css') }}" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">

    <!-- React + Babel CDN -->
    @include('partials.react-head')

    <!-- Legacy styles (for complex signup forms with FilePond, Select2, etc.) -->
    @yield('styles')

    <title>@yield('title', 'ETERA — Auto Parts Sourcing')</title>
</head>
<body class="etera-dark-body">

    <!-- Animated Background Circles -->
    <div class="etera-bg-circles">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </div>

    <!-- Main Content -->
    <div class="etera-auth-wrapper">
        <!-- Left Branding Panel -->
        <div class="etera-auth-branding">
            @yield('branding')
        </div>

        <!-- Right Form Panel -->
        <div class="etera-auth-form-side">
            <div class="etera-glass-card etera-auth-card">
                @yield('content')
            </div>
        </div>
    </div>

    <!-- Toast Notifications -->
    @include('partials.toast')

    <!-- Page-specific scripts -->
    @yield('scripts')

</body>
</html>
