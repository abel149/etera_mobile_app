<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="csrf-token" content="{{ csrf_token() }}">

	<!-- Favicon -->
	<link rel="icon" href="{{asset('favicon.ico')}}" type="image/x-icon"/>
	<link rel="icon" href="{{asset('assets/images/transparent.jpg')}}" type="image/jpeg"/>

	<!-- ETERA Modern Design System -->
	<link href="{{ asset('assets/css/etera-modern.css') }}" rel="stylesheet">

	<!-- Bootstrap CSS -->
	<link href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet">
	<link href="{{asset('assets/css/bootstrap-extended.css')}}" rel="stylesheet">

	<!-- Icons -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
	<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
	<link rel="stylesheet" href="{{asset('assets/css/icons.css')}}">

	<!-- Additional Plugins -->
	<link rel="stylesheet" href="{{asset('assets/plugins/select2/css/select2.min.css')}}" />
	<link rel="stylesheet" href="{{asset('assets/plugins/select2/css/select2-bootstrap-5-theme.min.css')}}" />
	{{-- lobibox removed – replaced by React toast system --}}

	<!-- FilePond core -->
	<link href="https://unpkg.com/filepond@^4/dist/filepond.css" rel="stylesheet" />
	<link href="https://unpkg.com/filepond-plugin-image-preview/dist/filepond-plugin-image-preview.min.css" rel="stylesheet">
	<link href="https://unpkg.com/filepond-plugin-image-edit/dist/filepond-plugin-image-edit.css" rel="stylesheet"/>

	@livewireStyles

	<style>
		/* ============================================
		   SPAREPART LAYOUT — DARK THEME OVERRIDES
		   ============================================ */

		html, body {
			height: 100%;
			margin: 0;
			padding: 0;
			font-family: 'Inter', sans-serif;
			background: var(--etera-bg-gradient);
			color: var(--etera-text);
		}

		body {
			display: flex;
			flex-direction: column;
		}

		.sp-main-content {
			flex: 1;
		}

		/* ---- Header ---- */
		.sp-header {
			background: rgba(10, 22, 40, 0.92);
			backdrop-filter: blur(20px);
			-webkit-backdrop-filter: blur(20px);
			border-bottom: 1px solid rgba(255, 255, 255, 0.06);
			position: sticky;
			top: 0;
			z-index: 1000;
			padding: 0 24px;
		}

		.sp-header-inner {
			max-width: 1200px;
			margin: 0 auto;
			display: flex;
			align-items: center;
			justify-content: space-between;
			height: 64px;
		}

		.sp-logo img {
			max-width: 7rem;
			transition: opacity 0.2s;
		}

		.sp-logo img:hover {
			opacity: 0.85;
		}

		/* Nav */
		.sp-nav {
			display: flex;
			align-items: center;
			gap: 4px;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		.sp-nav-link {
			color: var(--etera-text-muted);
			text-decoration: none;
			font-weight: 500;
			font-size: 0.9rem;
			padding: 8px 16px;
			border-radius: 8px;
			transition: all 0.25s ease;
			position: relative;
			display: inline-flex;
			align-items: center;
			gap: 6px;
		}

		.sp-nav-link:hover {
			color: #fff;
			background: rgba(13, 148, 136, 0.12);
		}

		.sp-nav-link.active {
			color: #fff;
			background: rgba(13, 148, 136, 0.2);
		}

		.sp-nav-link.active::after {
			content: '';
			position: absolute;
			bottom: 0;
			left: 50%;
			transform: translateX(-50%);
			width: 20px;
			height: 3px;
			border-radius: 3px;
			background: var(--etera-gradient);
		}

		.sp-badge {
			background: rgba(239, 68, 68, 0.9);
			color: #fff;
			padding: 2px 7px;
			border-radius: 50px;
			font-size: 0.7rem;
			font-weight: 700;
			min-width: 18px;
			text-align: center;
			line-height: 1.3;
		}

		.sp-badge-primary {
			background: rgba(13, 148, 136, 0.9);
		}

		.sp-badge-warning {
			background: rgba(245, 158, 11, 0.9);
		}

		/* User menu */
		.sp-user-menu {
			position: relative;
		}

		.sp-user-trigger {
			display: flex;
			align-items: center;
			gap: 10px;
			cursor: pointer;
			padding: 6px 12px;
			border-radius: 10px;
			transition: background 0.2s;
			text-decoration: none;
			color: #fff;
		}

		.sp-user-trigger:hover {
			background: rgba(255, 255, 255, 0.06);
			color: #fff;
		}

		.sp-avatar {
			width: 36px;
			height: 36px;
			border-radius: 50%;
			overflow: hidden;
			border: 2px solid rgba(13, 148, 136, 0.4);
		}

		.sp-avatar img {
			width: 100%;
			height: 100%;
			object-fit: cover;
		}

		.sp-user-name {
			font-size: 0.85rem;
			font-weight: 600;
		}

		.sp-user-role {
			font-size: 0.7rem;
			color: var(--etera-teal-light);
			display: block;
		}

		.sp-dropdown {
			position: absolute;
			top: calc(100% + 8px);
			right: 0;
			width: 220px;
			background: rgba(15, 39, 68, 0.98);
			backdrop-filter: blur(20px);
			border: 1px solid rgba(255, 255, 255, 0.08);
			border-radius: 12px;
			box-shadow: 0 16px 48px rgba(0, 0, 0, 0.4);
			display: none;
			padding: 8px;
			z-index: 1001;
		}

		.sp-user-menu:hover .sp-dropdown {
			display: block;
		}

		.sp-dropdown a,
		.sp-dropdown button {
			display: flex;
			align-items: center;
			gap: 10px;
			width: 100%;
			padding: 10px 14px;
			border-radius: 8px;
			font-size: 0.875rem;
			color: var(--etera-text-muted);
			text-decoration: none;
			border: none;
			background: none;
			cursor: pointer;
			transition: all 0.2s;
			font-family: 'Inter', sans-serif;
		}

		.sp-dropdown a:hover,
		.sp-dropdown button:hover {
			color: #fff;
			background: rgba(13, 148, 136, 0.15);
		}

		.sp-dropdown form {
			margin: 0;
		}

		/* Mobile nav toggle */
		.sp-mobile-toggle {
			display: none;
			background: none;
			border: none;
			color: #fff;
			font-size: 1.5rem;
			cursor: pointer;
			padding: 4px;
		}

		/* ---- Commission Banner ---- */
		.sp-commission-banner {
			max-width: 1200px;
			margin: 16px auto 0;
			padding: 12px 20px;
			background: rgba(13, 148, 136, 0.12);
			border: 1px solid rgba(13, 148, 136, 0.2);
			border-radius: 10px;
			font-size: 0.9rem;
			color: var(--etera-text-soft);
			text-align: center;
		}

		.sp-commission-banner strong {
			color: var(--etera-teal-light);
		}

		/* ---- Content Area ---- */
		.sp-content-wrapper {
			max-width: 1200px;
			margin: 0 auto;
			padding: 24px 16px;
		}

		/* ---- Dark Theme Overrides for Bootstrap Elements ---- */

		/* Cards */
		.card {
			background: rgba(255, 255, 255, 0.04) !important;
			border: 1px solid rgba(255, 255, 255, 0.08) !important;
			border-radius: 14px !important;
			color: #fff !important;
		}

		.card-header {
			background: rgba(13, 148, 136, 0.08) !important;
			border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
			color: #fff !important;
		}

		.card-body {
			color: #fff !important;
		}

		.card-footer {
			background: rgba(255, 255, 255, 0.02) !important;
			border-top: 1px solid rgba(255, 255, 255, 0.06) !important;
		}

		/* Tables */
		.table {
			color: #fff !important;
		}

		.table thead th {
			background: rgba(13, 148, 136, 0.1) !important;
			color: var(--etera-teal-light) !important;
			font-size: 0.8rem;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: 0.05em;
			border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
		}

		.table td {
			border-bottom: 1px solid rgba(255, 255, 255, 0.04) !important;
			vertical-align: middle;
		}

		.table-hover tbody tr:hover {
			background: rgba(13, 148, 136, 0.05) !important;
			color: #fff !important;
		}

		.table-striped > tbody > tr:nth-of-type(odd) > * {
			background: rgba(255, 255, 255, 0.02);
			color: #fff !important;
		}

		/* Forms */
		.form-control, .form-select {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 10px;
		}

		.form-control:focus, .form-select:focus {
			border-color: var(--etera-teal) !important;
			box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.2) !important;
			background: rgba(255, 255, 255, 0.08) !important;
			color: #fff !important;
		}

		.form-control::placeholder {
			color: rgba(255, 255, 255, 0.35) !important;
		}

		.form-label {
			color: var(--etera-text-soft) !important;
			font-weight: 600;
			font-size: 0.85rem;
		}

		.input-group-text {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: rgba(255, 255, 255, 0.6) !important;
		}

		/* Buttons */
		.btn-primary {
			background: var(--etera-gradient) !important;
			border: none !important;
			border-radius: 10px !important;
			font-weight: 600 !important;
			box-shadow: 0 4px 16px rgba(13, 148, 136, 0.3) !important;
			transition: all 0.3s ease !important;
		}

		.btn-primary:hover {
			transform: translateY(-2px);
			box-shadow: 0 8px 24px rgba(13, 148, 136, 0.4) !important;
		}

		.btn-outline-primary {
			border-color: var(--etera-teal) !important;
			color: var(--etera-teal-light) !important;
			border-radius: 10px !important;
		}

		.btn-outline-primary:hover {
			background: rgba(13, 148, 136, 0.15) !important;
			color: #fff !important;
		}

		.btn-success {
			background: rgba(16, 185, 129, 0.9) !important;
			border: none !important;
			border-radius: 10px !important;
		}

		.btn-danger {
			background: rgba(239, 68, 68, 0.9) !important;
			border: none !important;
			border-radius: 10px !important;
		}

		.btn-warning {
			background: rgba(245, 158, 11, 0.9) !important;
			border: none !important;
			border-radius: 10px !important;
			color: #1a1a1a !important;
		}

		.btn-info {
			background: rgba(59, 130, 246, 0.9) !important;
			border: none !important;
			border-radius: 10px !important;
		}

		.btn-light, .btn-secondary {
			background: rgba(255, 255, 255, 0.08) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 10px !important;
		}

		.btn-light:hover, .btn-secondary:hover {
			background: rgba(255, 255, 255, 0.14) !important;
		}

		/* Badges */
		.badge.bg-primary { background: rgba(13, 148, 136, 0.8) !important; }
		.badge.bg-success { background: rgba(16, 185, 129, 0.8) !important; }
		.badge.bg-danger  { background: rgba(239, 68, 68, 0.8) !important; }
		.badge.bg-warning { background: rgba(245, 158, 11, 0.9) !important; color: #1a1a1a !important; }
		.badge.bg-info    { background: rgba(59, 130, 246, 0.8) !important; }
		.badge.bg-secondary { background: rgba(255, 255, 255, 0.12) !important; }

		/* Modals */
		.modal-content {
			background: rgba(15, 39, 68, 0.98) !important;
			backdrop-filter: blur(20px);
			border: 1px solid rgba(255, 255, 255, 0.08) !important;
			color: #fff !important;
			border-radius: 16px !important;
		}

		.modal-header {
			border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
		}

		.modal-footer {
			border-top: 1px solid rgba(255, 255, 255, 0.08) !important;
		}

		.btn-close {
			filter: invert(1);
		}

		/* Alerts */
		.alert {
			border-radius: 10px !important;
			border: none !important;
		}

		.alert-success {
			background: rgba(16, 185, 129, 0.15) !important;
			color: #6ee7b7 !important;
			border-left: 4px solid #10b981 !important;
		}

		.alert-danger {
			background: rgba(239, 68, 68, 0.15) !important;
			color: #fca5a5 !important;
			border-left: 4px solid #ef4444 !important;
		}

		.alert-warning {
			background: rgba(245, 158, 11, 0.15) !important;
			color: #fcd34d !important;
			border-left: 4px solid #f59e0b !important;
		}

		.alert-info {
			background: rgba(59, 130, 246, 0.15) !important;
			color: #93c5fd !important;
			border-left: 4px solid #3b82f6 !important;
		}

		/* Accordion */
		.accordion-button {
			background: rgba(255, 255, 255, 0.04) !important;
			color: #fff !important;
		}

		.accordion-body {
			background: rgba(255, 255, 255, 0.02) !important;
			color: var(--etera-text-muted) !important;
		}

		/* Pagination */
		.page-link {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.1) !important;
			color: var(--etera-text-muted) !important;
			border-radius: 8px !important;
		}

		.page-item.active .page-link {
			background: var(--etera-gradient) !important;
			border-color: transparent !important;
			color: #fff !important;
		}

		.page-link:hover {
			background: rgba(13, 148, 136, 0.15) !important;
			color: #fff !important;
		}

		/* Select2 Dark Theme */
		.select2-container--default .select2-selection--single,
		.select2-container--default .select2-selection--multiple {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 10px !important;
			min-height: 42px;
		}

		.select2-container--default .select2-selection--single .select2-selection__rendered {
			color: #fff !important;
		}

		.select2-container--default .select2-selection--multiple .select2-selection__choice {
			background: rgba(13, 148, 136, 0.3) !important;
			border: 1px solid rgba(13, 148, 136, 0.5) !important;
			color: #fff !important;
			border-radius: 6px !important;
		}

		.select2-dropdown {
			background: #1a2744 !important;
			border-color: rgba(255, 255, 255, 0.12) !important;
		}

		.select2-results__option { color: #fff !important; }
		.select2-results__option--highlighted { background: rgba(13, 148, 136, 0.3) !important; }
		.select2-search__field { background: rgba(255, 255, 255, 0.06) !important; color: #fff !important; }

		/* FilePond Dark Theme */
		.filepond--drop-label {
			border: 2px dashed rgba(255, 255, 255, 0.15) !important;
			background: rgba(255, 255, 255, 0.03) !important;
			color: rgba(255, 255, 255, 0.5) !important;
			border-radius: 10px;
		}

		.filepond--label-action {
			color: var(--etera-teal-light) !important;
			text-decoration-color: var(--etera-teal-light) !important;
		}

		.filepond--panel-root {
			background: rgba(255, 255, 255, 0.03) !important;
		}

		.filepond--file {
			background: var(--etera-teal) !important;
		}

		/* Misc text colors */
		.text-muted { color: var(--etera-text-muted) !important; }
		.text-dark { color: var(--etera-text-soft) !important; }
		h1, h2, h3, h4, h5, h6 { color: #fff; }
		p { color: var(--etera-text-muted); }
		a { color: var(--etera-teal-light); }
		a:hover { color: #fff; }
		hr { border-color: rgba(255, 255, 255, 0.08); }

		/* Tooltip overrides */
		.tooltip-inner {
			background-color: #1a2744 !important;
			color: #fff !important;
			font-size: 0.85rem;
			padding: 10px 14px;
			border-radius: 8px;
			box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
		}

		/* Commission info glow */
		.commission-info-icon {
			width: 22px; height: 22px;
			border-radius: 50%;
			display: inline-flex;
			align-items: center; justify-content: center;
			font-weight: bold; font-size: 14px;
			cursor: pointer; color: #fff;
			background: linear-gradient(45deg, var(--etera-teal), var(--etera-blue));
			box-shadow: 0 0 8px rgba(13, 148, 136, 0.6);
			animation: commissionGlow 1.5s infinite alternate;
			user-select: none;
		}

		@keyframes commissionGlow {
			0% { box-shadow: 0 0 6px var(--etera-teal); }
			100% { box-shadow: 0 0 14px var(--etera-blue); }
		}

		/* ---- Footer ---- */
		.sp-footer {
			background: rgba(10, 22, 40, 0.95);
			border-top: 1px solid rgba(255, 255, 255, 0.06);
			padding: 24px 0;
			margin-top: auto;
		}

		.sp-footer-inner {
			max-width: 1200px;
			margin: 0 auto;
			padding: 0 16px;
			display: flex;
			align-items: center;
			justify-content: space-between;
		}

		.sp-footer-brand {
			font-size: 1.2rem;
			font-weight: 800;
			background: var(--etera-gradient);
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
			background-clip: text;
		}

		.sp-footer-copy {
			color: var(--etera-text-muted);
			font-size: 0.8rem;
		}

		.sp-footer-social {
			display: flex;
			gap: 12px;
			list-style: none;
			margin: 0;
			padding: 0;
		}

		.sp-footer-social a {
			color: var(--etera-text-muted);
			font-size: 1.1rem;
			transition: color 0.2s;
		}

		.sp-footer-social a:hover {
			color: var(--etera-teal-light);
		}

		/* ---- Responsive ---- */
		@media (max-width: 992px) {
			.sp-nav {
				display: none;
				position: absolute;
				top: 64px;
				left: 0;
				right: 0;
				background: rgba(10, 22, 40, 0.98);
				flex-direction: column;
				padding: 16px;
				border-bottom: 1px solid rgba(255, 255, 255, 0.06);
				gap: 4px;
			}

			.sp-nav.open {
				display: flex;
			}

			.sp-mobile-toggle {
				display: block;
			}

			.sp-user-name-text {
				display: none;
			}

			.sp-footer-inner {
				flex-direction: column;
				gap: 12px;
				text-align: center;
			}
		}

		/* ============================================
		   LEGACY THEME OVERRIDES — Dark compatibility
		   These cover old classes from the previous light
		   theme that are still used in spare-part views.
		   ============================================ */

		/* Dashboard Box (profile, settings pages) */
		.dashboard-box {
			background: rgba(255, 255, 255, 0.04);
			border: 1px solid rgba(255, 255, 255, 0.08);
			border-radius: 14px;
			overflow: hidden;
			margin-bottom: 20px;
		}

		.dashboard-box .headline {
			background: rgba(13, 148, 136, 0.08);
			padding: 16px 20px;
			border-bottom: 1px solid rgba(255, 255, 255, 0.06);
		}

		.dashboard-box .headline h3 {
			color: #fff !important;
			font-size: 1rem;
			font-weight: 700;
			margin: 0;
		}

		.dashboard-box .headline h3 i {
			color: var(--etera-teal-light);
			margin-right: 8px;
		}

		.dashboard-box .content {
			padding: 20px;
		}

		.content.with-padding {
			padding: 20px;
		}

		/* Submit fields (form inputs in old theme) */
		.submit-field {
			margin-bottom: 18px;
		}

		.submit-field h5 {
			color: var(--etera-text-soft) !important;
			font-size: 0.85rem;
			font-weight: 600;
			margin-bottom: 8px;
		}

		/* Legacy .with-border inputs */
		input.with-border,
		textarea.with-border,
		select.with-border {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 10px;
			padding: 10px 14px;
			width: 100%;
			font-family: 'Inter', sans-serif;
			font-size: 0.9rem;
			transition: all 0.25s ease;
			outline: none;
		}

		input.with-border:focus,
		textarea.with-border:focus,
		select.with-border:focus {
			border-color: var(--etera-teal) !important;
			box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.2);
			background: rgba(255, 255, 255, 0.08) !important;
		}

		input.with-border::placeholder {
			color: rgba(255, 255, 255, 0.35) !important;
		}

		/* Legacy .button (non-Bootstrap) */
		.button {
			background: var(--etera-gradient) !important;
			color: #fff !important;
			border: none !important;
			padding: 12px 24px;
			border-radius: 10px;
			font-weight: 600;
			font-family: 'Inter', sans-serif;
			cursor: pointer;
			transition: all 0.3s ease;
			display: inline-block;
			text-decoration: none;
			font-size: 0.9rem;
			box-shadow: 0 4px 16px rgba(13, 148, 136, 0.3);
		}

		.button:hover {
			transform: translateY(-2px);
			box-shadow: 0 8px 24px rgba(13, 148, 136, 0.4) !important;
			color: #fff !important;
		}

		.button.gray {
			background: rgba(255, 255, 255, 0.08) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			box-shadow: none;
		}

		.button.gray:hover {
			background: rgba(255, 255, 255, 0.14) !important;
		}

		.button.small {
			padding: 6px 14px;
			font-size: 0.8rem;
		}

		/* Notify Box (header for listing pages) */
		.notify-box {
			display: flex;
			align-items: center;
			justify-content: space-between;
			background: rgba(255, 255, 255, 0.04);
			border: 1px solid rgba(255, 255, 255, 0.08);
			border-radius: 14px;
			padding: 16px 20px;
			margin-bottom: 16px;
		}

		.switch-container h3.page-title,
		h3.page-title {
			color: #fff !important;
			font-size: 1.1rem;
			font-weight: 700;
			margin: 0;
		}

		.sort-by {
			display: flex;
			align-items: center;
			gap: 8px;
			color: var(--etera-text-muted);
			font-size: 0.85rem;
		}

		.sort-by select,
		.selectpicker {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 8px;
			padding: 6px 12px;
			font-size: 0.85rem;
			outline: none;
		}

		/* Job Listing Cards (inbox, received, etc.) */
		.job-listing,
		a.job-listing {
			background: rgba(255, 255, 255, 0.04) !important;
			border: 1px solid rgba(255, 255, 255, 0.08) !important;
			border-radius: 14px !important;
			margin-bottom: 12px !important;
			padding: 16px 20px !important;
			display: flex !important;
			align-items: center !important;
			text-decoration: none !important;
			transition: all 0.25s ease !important;
			color: #fff !important;
		}

		.job-listing:hover,
		a.job-listing:hover {
			border-color: rgba(13, 148, 136, 0.3) !important;
			background: rgba(13, 148, 136, 0.06) !important;
			transform: translateY(-2px);
			box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
		}

		.job-listing-details {
			display: flex;
			align-items: center;
			width: 100%;
			gap: 16px;
		}

		.job-listing-company-logo {
			width: 48px;
			height: 48px;
			flex-shrink: 0;
			border-radius: 10px;
			overflow: hidden;
			background: rgba(255, 255, 255, 0.06);
		}

		.job-listing-company-logo img {
			width: 100%;
			height: 100%;
			object-fit: cover;
		}

		.job-listing-description {
			flex: 1;
		}

		.job-listing-title {
			color: #fff !important;
			font-size: 1rem !important;
			font-weight: 600 !important;
			margin: 0 0 4px !important;
		}

		.job-listing-footer ul {
			list-style: none;
			padding: 0;
			margin: 0;
			display: flex;
			flex-wrap: wrap;
			gap: 16px;
		}

		.job-listing-footer ul li {
			color: var(--etera-text-muted);
			font-size: 0.82rem;
			display: flex;
			align-items: center;
			gap: 4px;
		}

		.job-listing-footer ul li i {
			color: var(--etera-teal-light);
			font-size: 0.9rem;
		}

		.job-listing-text {
			color: var(--etera-text-muted) !important;
		}

		/* Apply / Details button in listings */
		.list-apply-button {
			background: rgba(13, 148, 136, 0.15) !important;
			color: var(--etera-teal-light) !important;
			border: 1px solid rgba(13, 148, 136, 0.3) !important;
			padding: 8px 20px !important;
			border-radius: 50px !important;
			font-size: 0.82rem !important;
			font-weight: 600 !important;
			white-space: nowrap !important;
			flex-shrink: 0 !important;
			text-decoration: none !important;
			transition: all 0.25s ease !important;
		}

		.list-apply-button:hover {
			background: rgba(13, 148, 136, 0.25) !important;
			color: #fff !important;
		}

		/* Compact list layout */
		.compact-list-layout .job-listing {
			padding: 14px 18px !important;
		}

		/* Counters (profile page) */
		.counters-container {
			display: flex;
			gap: 16px;
			flex-wrap: wrap;
		}

		.single-counter {
			flex: 1;
			min-width: 180px;
			background: rgba(255, 255, 255, 0.04);
			border: 1px solid rgba(255, 255, 255, 0.08);
			border-radius: 14px;
			padding: 20px;
			display: flex;
			align-items: center;
			gap: 14px;
			transition: all 0.25s ease;
		}

		.single-counter:hover {
			border-color: rgba(13, 148, 136, 0.2);
			background: rgba(13, 148, 136, 0.04);
		}

		.single-counter i {
			font-size: 2rem;
			color: var(--etera-teal-light);
		}

		.counter-inner h3 {
			color: #fff;
			font-size: 1.4rem;
			font-weight: 800;
			margin: 0;
		}

		.counter-title {
			color: var(--etera-text-muted);
			font-size: 0.8rem;
		}

		/* Keywords container (brand selector) */
		.keywords-container {
			margin-top: 4px;
		}

		.keyword-select {
			background: rgba(255, 255, 255, 0.06) !important;
			color: #fff !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			border-radius: 10px;
			width: 100%;
		}

		/* Table overrides for legacy styles */
		.table-light,
		.table-light th,
		.table-light td,
		thead.table-light {
			background: rgba(13, 148, 136, 0.1) !important;
			color: var(--etera-teal-light) !important;
			border-color: rgba(255, 255, 255, 0.06) !important;
		}

		.table-bordered {
			border-color: rgba(255, 255, 255, 0.06) !important;
		}

		.table-bordered td,
		.table-bordered th {
			border-color: rgba(255, 255, 255, 0.06) !important;
		}

		tfoot tr {
			border-color: rgba(255, 255, 255, 0.06) !important;
		}

		.table-striped > tbody > tr:nth-of-type(odd) > * {
			background: rgba(255, 255, 255, 0.02) !important;
			color: #fff !important;
		}

		/* Old shadow-sm override */
		.shadow-sm {
			box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2) !important;
		}

		/* Colored left borders on cards */
		.border-start.border-warning { border-color: #f59e0b !important; }
		.border-start.border-success { border-color: #10b981 !important; }
		.border-start.border-primary { border-color: var(--etera-teal) !important; }
		.border-start.border-danger  { border-color: #ef4444 !important; }

		.border-top.border-warning { border-color: #f59e0b !important; }
		.border-top.border-success { border-color: #10b981 !important; }
		.border-top.border-primary { border-color: var(--etera-teal) !important; }
		.border-top.border-danger  { border-color: #ef4444 !important; }

		/* Text color utility extras */
		.text-primary { color: var(--etera-teal-light) !important; }
		.text-success { color: #10b981 !important; }
		.text-warning { color: #f59e0b !important; }
		.text-danger  { color: #ef4444 !important; }

		/* bg-light override */
		.bg-light {
			background: rgba(255, 255, 255, 0.06) !important;
			color: #fff !important;
		}

		.badge.bg-light {
			color: var(--etera-text-muted) !important;
			border: 1px solid rgba(255, 255, 255, 0.15) !important;
		}

		/* Legacy margin utilities */
		.margin-top-15  { margin-top: 15px; }
		.margin-top-20  { margin-top: 20px; }
		.margin-top-30  { margin-top: 30px; }
		.margin-top-35  { margin-top: 35px; }
		.margin-top-45  { margin-top: 45px; }
		.margin-bottom-45 { margin-bottom: 45px; }

		/* Modal header inline-style fix */
		.modal-header[style*="background-color"] {
			background: rgba(13, 148, 136, 0.2) !important;
			border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
		}

		/* Profile pic / avatar in legacy views */
		.profile-pic, .pp {
			width: 100px;
			height: 100px;
			border-radius: 12px;
			object-fit: cover;
			border: 2px solid rgba(255, 255, 255, 0.1);
		}

		/* Upload button overlay */
		.upload-button, .ub {
			cursor: pointer;
		}

		/* Fullscreen modal (images) */
		.fullscreen-modal {
			background-color: rgba(0, 0, 0, 0.9) !important;
		}

		/* Livewire component dark overrides */
		[wire\:id] .card,
		[wire\:id] .card-header,
		[wire\:id] .card-body {
			background: rgba(255, 255, 255, 0.04) !important;
			color: #fff !important;
			border-color: rgba(255, 255, 255, 0.08) !important;
		}

		[wire\:id] input,
		[wire\:id] select,
		[wire\:id] textarea {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 10px !important;
		}

		[wire\:id] input:focus,
		[wire\:id] select:focus,
		[wire\:id] textarea:focus {
			border-color: var(--etera-teal) !important;
			box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.2) !important;
		}

		[wire\:id] label {
			color: var(--etera-text-soft) !important;
			font-weight: 600;
			font-size: 0.85rem;
		}

		[wire\:id] .text-dark {
			color: var(--etera-text-soft) !important;
		}

		/* Ripple effect override */
		.ripple-effect {
			position: relative;
			overflow: hidden;
		}

		/* ============================================
		   GLOBAL TEXT CONTRAST — ensure all text is
		   readable on the dark background
		   ============================================ */
		body, .container, .row, div, section, main, article, aside, footer {
			color: #fff;
		}

		h1, h2, h3, h4, h5, h6 {
			color: #fff !important;
		}

		p, span, label, small, li, td, th, strong, b, em, i:not([class]),
		.mb-0, .mb-1, .mb-2, .mb-3, .mb-4 {
			color: inherit;
		}

		.text-muted {
			color: var(--etera-text-muted, rgba(255,255,255,0.5)) !important;
		}

		.text-secondary {
			color: var(--etera-text-soft, rgba(255,255,255,0.7)) !important;
		}

		.text-dark {
			color: var(--etera-text-soft, rgba(255,255,255,0.7)) !important;
		}

		/* Sidebar widget (proforma details page) */
		.sidebar-widget {
			background: rgba(255, 255, 255, 0.04);
			border: 1px solid rgba(255, 255, 255, 0.08);
			border-radius: 14px;
			overflow: hidden;
		}

		.job-overview {
			background: transparent;
		}

		.job-overview-headline {
			background: rgba(13, 148, 136, 0.08);
			color: var(--etera-teal-light) !important;
			padding: 14px 20px;
			font-weight: 700;
			font-size: 0.95rem;
			border-bottom: 1px solid rgba(255, 255, 255, 0.06);
		}

		.job-overview-inner ul {
			list-style: none;
			padding: 0;
			margin: 0;
		}

		.job-overview-inner ul li {
			padding: 12px 20px;
			border-bottom: 1px solid rgba(255, 255, 255, 0.04);
			color: #fff;
		}

		.job-overview-inner ul li i {
			color: var(--etera-teal-light);
			margin-right: 8px;
		}

		.job-overview-inner ul li span {
			display: block;
			font-size: 0.78rem;
			color: var(--etera-text-muted);
			margin-bottom: 2px;
		}

		.job-overview-inner ul li h5 {
			font-size: 0.9rem !important;
			font-weight: 600;
			margin: 0;
		}

		/* Single page header (proforma details banner) */
		.single-page-header {
			background: rgba(255, 255, 255, 0.04) !important;
			padding: 30px 0;
		}

		.single-page-header-inner {
			display: flex;
			align-items: center;
			gap: 20px;
		}

		.header-image img {
			width: 60px;
			height: 60px;
			border-radius: 12px;
			object-fit: cover;
			border: 2px solid rgba(255, 255, 255, 0.1);
		}

		.header-details h3, .header-details h5 {
			color: #fff !important;
		}

		.header-details ul {
			list-style: none;
			padding: 0;
			margin: 8px 0 0;
			display: flex;
			flex-wrap: wrap;
			gap: 16px;
		}

		.header-details ul li {
			color: var(--etera-text-muted);
			font-size: 0.85rem;
		}

		.header-details ul li i {
			color: var(--etera-teal-light);
			margin-right: 4px;
		}

		/* Section headline */
		.section-headline h3 {
			color: #fff !important;
			font-weight: 700;
		}

		/* Basic table (proforma details page) */
		.basic-table {
			border: 1px solid rgba(255, 255, 255, 0.08) !important;
		}

		.basic-table th {
			background: rgba(13, 148, 136, 0.12) !important;
			color: var(--etera-teal-light) !important;
			border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
		}

		.basic-table td {
			border-bottom: 1px solid rgba(255, 255, 255, 0.04) !important;
			color: #fff !important;
		}

		.basic-table tr:hover {
			background: rgba(13, 148, 136, 0.04) !important;
		}

		.basic-table tfoot tr {
			background: rgba(13, 148, 136, 0.06) !important;
		}

		.basic-table input[type="number"] {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 8px;
		}

		.basic-table input[type="number"]:disabled {
			background: rgba(255, 255, 255, 0.03) !important;
			color: var(--etera-text-muted) !important;
		}

		/* Generic table overrides for received-details */
		table th {
			background: rgba(13, 148, 136, 0.12) !important;
			color: var(--etera-teal-light) !important;
		}

		table tr:nth-child(odd) {
			background: rgba(255, 255, 255, 0.02) !important;
		}

		tfoot tr:nth-child(odd) {
			background: rgba(13, 148, 136, 0.06) !important;
			color: var(--etera-teal-light) !important;
		}

		table td {
			color: #fff !important;
		}

		/* Form controls (Bootstrap) */
		.form-control,
		.form-select {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 10px !important;
		}

		.form-control:focus,
		.form-select:focus {
			border-color: var(--etera-teal) !important;
			box-shadow: 0 0 0 3px rgba(13, 148, 136, 0.2) !important;
			background: rgba(255, 255, 255, 0.08) !important;
		}

		.form-control::placeholder {
			color: rgba(255, 255, 255, 0.35) !important;
		}

		.form-label {
			color: var(--etera-text-soft) !important;
			font-weight: 600;
			font-size: 0.85rem;
		}

		/* Input with icon */
		.input-with-icon {
			position: relative;
		}

		.input-with-icon input {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
			border-radius: 10px !important;
			padding-right: 40px;
		}

		.input-with-icon i {
			color: var(--etera-text-muted) !important;
		}

		/* Bootstrap card overrides */
		.card {
			background: rgba(255, 255, 255, 0.04) !important;
			border: 1px solid rgba(255, 255, 255, 0.08) !important;
			border-radius: 14px !important;
			color: #fff !important;
		}

		.card-header {
			background: rgba(13, 148, 136, 0.06) !important;
			border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
			color: #fff !important;
		}

		.card-body {
			color: #fff !important;
		}

		.card-footer {
			background: rgba(255, 255, 255, 0.02) !important;
			border-top: 1px solid rgba(255, 255, 255, 0.06) !important;
			color: #fff !important;
		}

		/* Modal dark overrides */
		.modal-content {
			background: var(--etera-bg, #0c1222) !important;
			border: 1px solid rgba(255, 255, 255, 0.1) !important;
			border-radius: 16px !important;
			color: #fff !important;
		}

		.modal-header {
			background: rgba(13, 148, 136, 0.08) !important;
			border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
			color: #fff !important;
		}

		.modal-header .modal-title {
			color: #fff !important;
		}

		.modal-header .btn-close {
			filter: invert(1) !important;
			opacity: 0.7;
		}

		.modal-body {
			color: #fff !important;
		}

		.modal-footer {
			background: rgba(255, 255, 255, 0.02) !important;
			border-top: 1px solid rgba(255, 255, 255, 0.08) !important;
		}

		/* Pagination dark override */
		.pagination .page-link {
			background: rgba(255, 255, 255, 0.06) !important;
			border: 1px solid rgba(255, 255, 255, 0.1) !important;
			color: var(--etera-text-soft) !important;
		}

		.pagination .page-item.active .page-link {
			background: var(--etera-gradient) !important;
			border-color: transparent !important;
			color: #fff !important;
		}

		.pagination .page-link:hover {
			background: rgba(13, 148, 136, 0.15) !important;
			color: var(--etera-teal-light) !important;
		}

		/* Invoice card dark overrides */
		.invoice-card {
			background: rgba(255, 255, 255, 0.04) !important;
			border: 1px solid rgba(255, 255, 255, 0.08) !important;
		}

		.invoice-details {
			color: #fff !important;
		}

		.invoice-details strong {
			color: var(--etera-teal-light) !important;
		}

		.invoice-table thead th {
			background: rgba(13, 148, 136, 0.12) !important;
			color: var(--etera-teal-light) !important;
		}

		.invoice-table td {
			border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
			color: #fff !important;
		}

		.invoice-summary {
			background: rgba(255, 255, 255, 0.04) !important;
			color: #fff !important;
		}

		/* Stamp image */
		.profile-pic.stamp-image {
			border-color: rgba(255, 255, 255, 0.15) !important;
		}

		/* Apply now button */
		.apply-now-button {
			background: var(--etera-gradient) !important;
			color: #fff !important;
			border: none !important;
			border-radius: 50px;
			font-weight: 600;
			transition: all 0.3s ease;
			box-shadow: 0 4px 16px rgba(13, 148, 136, 0.3);
		}

		.apply-now-button:hover {
			transform: translateY(-2px);
			box-shadow: 0 8px 24px rgba(13, 148, 136, 0.4) !important;
		}

		/* Notification notice */
		.notification.notice {
			background: rgba(255, 255, 255, 0.04) !important;
			border: 1px solid rgba(255, 255, 255, 0.08) !important;
			border-radius: 12px;
			padding: 20px;
			color: var(--etera-text-muted) !important;
		}

		/* Alert overrides */
		.alert-success {
			background: rgba(16, 185, 129, 0.15) !important;
			border-color: rgba(16, 185, 129, 0.3) !important;
			color: #10b981 !important;
		}

		.alert-dismissible .btn-close {
			filter: invert(1);
		}

		/* btn-outline-primary dark override */
		.btn-outline-primary {
			color: var(--etera-teal-light) !important;
			border-color: var(--etera-teal) !important;
		}

		.btn-outline-primary:hover,
		.btn-outline-primary.active {
			background: var(--etera-teal) !important;
			color: #fff !important;
		}

		.btn-primary {
			background: var(--etera-gradient) !important;
			border: none !important;
			color: #fff !important;
		}

		.btn-outline-secondary {
			color: var(--etera-text-soft) !important;
			border-color: rgba(255, 255, 255, 0.2) !important;
		}

		.btn-outline-secondary:hover {
			background: rgba(255, 255, 255, 0.08) !important;
			color: #fff !important;
		}

		.btn-secondary {
			background: rgba(255, 255, 255, 0.08) !important;
			border: 1px solid rgba(255, 255, 255, 0.12) !important;
			color: #fff !important;
		}

		/* Padding utilities */
		.padding-left-20 { padding-left: 20px; }
		.padding-right-20 { padding-right: 20px; }
	</style>

	@if(auth()->user()->role == 'garage')
		<title>ETERA - Garages</title>
	@elseif(auth()->user()->role == 'shop')
		<title>ETERA - Spare Part Shops</title>
	@endif

	<!-- React + Babel CDN -->
	@include('partials.react-head')
</head>

<body>

@php
    $commission = \App\Models\Commission::first();
    $role = auth()->user()->role ?? null;
    $payAmount = match ($role) {
        'garage' => $commission?->garagePay,
        'shop'   => $commission?->shopPay,
        default  => null,
    };
@endphp

<!-- Animated Background Circles -->
<div class="etera-bg-circles">
	<div class="circle"></div>
	<div class="circle"></div>
	<div class="circle"></div>
</div>

<!-- Header -->
<header class="sp-header">
	<div class="sp-header-inner">
		<!-- Logo -->
		<a href="/spare-part-shops/proformas" class="sp-logo">
			<img src="{{asset('assets/images/transparent.svg')}}" alt="ETERA">
		</a>

		<!-- Mobile Toggle -->
		<button class="sp-mobile-toggle" id="sp-mobile-toggle" aria-label="Toggle navigation">
			<i class="bi bi-list"></i>
		</button>

		<!-- Navigation -->
		<ul class="sp-nav" id="sp-nav">
			@if(auth()->user()?->role == 'shop')
				<li><a href="/spare-part-shops/proformas" class="sp-nav-link @yield('insurance')">Proformas</a></li>
				<li><a href="/my-applications" class="sp-nav-link @yield('applications')">My Applications</a></li>
				<li><a href="/spare-part-shops/balance" class="sp-nav-link @yield('balance')">Balance</a></li>
				<li>
					<a href="/spare-part-shops/inbox" class="sp-nav-link @yield('inbox')">
						Inbox
						@if(auth()->user()->getInboxCount() > 0)
							<span class="sp-badge">{{ auth()->user()->getInboxCount() }}</span>
						@endif
					</a>
				</li>
			@endif

			@if(auth()->user()?->role == 'garage')
				<li><a href="/garage/proformas" class="sp-nav-link @yield('insurance')">Proformas</a></li>
				<li><a href="/my-applications" class="sp-nav-link @yield('applications')">My Applications</a></li>
				<li><a href="/garage/my-files" class="sp-nav-link @yield('post')">My Files</a></li>
				<li><a href="/garage/create-file" class="sp-nav-link">Request Proforma</a></li>
				<li>
					<a href="/garage/received-proformas" class="sp-nav-link @yield('received')">
						Received
						@if(auth()->user()->getReceivedProformasCount() > 0)
							<span class="sp-badge sp-badge-primary">{{ auth()->user()->getReceivedProformasCount() }}</span>
						@endif
						@if(auth()->user()->getReturnedFromAdminCount() > 0)
							<span class="sp-badge">{{ auth()->user()->getReturnedFromAdminCount() }}</span>
						@endif
					</a>
				</li>
				<li><a href="/garage/balance" class="sp-nav-link @yield('balance')">Balance</a></li>
				<li>
					<a href="/garage/inbox" class="sp-nav-link @yield('inbox')">
						Inbox
						@if(auth()->user()->getInboxCount() > 0)
							<span class="sp-badge sp-badge-warning">{{ auth()->user()->getInboxCount() }}</span>
						@elseif(auth()->user()->unReadMessages() > 0)
							<span class="sp-badge">{{ auth()->user()->unReadMessages() }}</span>
						@endif
					</a>
				</li>
			@endif
		</ul>

		<!-- User Menu -->
		<div class="sp-user-menu">
			<a href="#" class="sp-user-trigger">
				<div class="sp-avatar">
					<img src="{{asset('asset/images/company-logo-03a.png')}}" alt="Avatar">
				</div>
				<div class="sp-user-name-text">
					<span class="sp-user-name">{{ucfirst(auth()->user()->name)}}</span>
					<span class="sp-user-role">{{ucfirst(auth()->user()->role)}}</span>
				</div>
			</a>

			<div class="sp-dropdown">
				@if(auth()->user()->role == 'garage')
					<a href="/garage/profile"><i class="bi bi-gear"></i> Settings</a>
				@elseif(auth()->user()->role == 'shop')
					<a href="/spare-part-shops/profile"><i class="bi bi-gear"></i> Settings</a>
				@endif
				<form action="{{route('logout')}}" method="POST">
					@method("DELETE")
					@csrf
					<button type="submit"><i class="bi bi-box-arrow-right"></i> Logout</button>
				</form>
			</div>
		</div>
	</div>
</header>

<!-- Commission Banner -->
@if($payAmount)
<div class="sp-commission-banner">
	💰 Earn <strong>{{ $payAmount }} birr</strong> for every <strong>Insurance Proforma</strong> you fill out!
</div>
@endif

<!-- Main Content -->
<div class="sp-main-content">
	<div class="sp-content-wrapper">
		@yield('content')
	</div>
</div>

<!-- Footer -->
<footer class="sp-footer">
	<div class="sp-footer-inner">
		<span class="sp-footer-brand">ETERA</span>
		<span class="sp-footer-copy">© <script>document.write(new Date().getFullYear())</script>. All rights reserved.</span>
		<ul class="sp-footer-social">
			<li><a href="#"><i class="bi bi-facebook"></i></a></li>
			<li><a href="#"><i class="bi bi-twitter-x"></i></a></li>
			<li><a href="#"><i class="bi bi-linkedin"></i></a></li>
		</ul>
	</div>
</footer>

<!-- Toast Notifications (React) -->
@include('partials.toast')

<!-- CSRF Auto-Refresh -->
@include('partials.csrf-refresh')

<!-- Scripts (jQuery → Bootstrap → plugins) -->
<script src="{{asset('asset/js/jquery-3.4.1.min.js')}}"></script>
<script src="{{asset('assets/js/bootstrap.bundle.min.js')}}"></script>

<script>
	// Mobile nav toggle
	document.getElementById('sp-mobile-toggle')?.addEventListener('click', function() {
		document.getElementById('sp-nav')?.classList.toggle('open');
	});

	// Bootstrap tooltip init
	document.addEventListener('DOMContentLoaded', function () {
		var tooltipList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
		tooltipList.map(function (el) { return new bootstrap.Tooltip(el); });

		// Allow modal buttons to receive clicks
		document.querySelectorAll('.modal .btn, .modal .btn-close, .modal [data-bs-dismiss], .modal [data-bs-slide]')
			.forEach(function(el){ el.style.pointerEvents = 'auto'; });
	});
</script>

@hasSection('minimalScripts')
@else
<script src="{{asset('asset/js/mmenu.min.js')}}"></script>
<script src="{{asset('asset/js/tippy.all.min.js')}}"></script>
<script src="{{asset('asset/js/simplebar.min.js')}}"></script>
<script src="{{asset('asset/js/bootstrap-slider.min.js')}}"></script>
<script src="{{asset('asset/js/bootstrap-select.min.js')}}"></script>
<script src="{{asset('asset/js/snackbar.js')}}"></script>
<script src="{{asset('asset/js/clipboard.min.js')}}"></script>
<script src="{{asset('asset/js/counterup.min.js')}}"></script>
<script src="{{asset('asset/js/magnific-popup.min.js')}}"></script>
<script src="{{asset('asset/js/slick.min.js')}}"></script>
<script src="{{asset('asset/js/custom.js')}}"></script>
@endif

<!-- Additional Plugin Scripts -->
<script src="{{asset('assets/plugins/simplebar/js/simplebar.min.js')}}"></script>
<script src="{{asset('assets/plugins/metismenu/js/metisMenu.min.js')}}"></script>
<script src="{{asset('assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js')}}"></script>
<script src="{{asset('assets/plugins/Drag-And-Drop/dist/imageuploadify.min.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="{{asset('assets/plugins/select2/js/select2-custom.js')}}"></script>
{{-- lobibox/notification scripts removed – replaced by React toast system --}}
<script src="{{asset('assets/js/app.js')}}"></script>

<!-- FilePond Scripts -->
<script src="https://unpkg.com/filepond-plugin-file-validate-size/dist/filepond-plugin-file-validate-size.js"></script>
<script src="https://unpkg.com/filepond-plugin-file-validate-type/dist/filepond-plugin-file-validate-type.js"></script>
<script src="https://unpkg.com/filepond-plugin-image-crop/dist/filepond-plugin-image-crop.js"></script>
<script src="https://unpkg.com/filepond-plugin-image-edit/dist/filepond-plugin-image-edit.js"></script>
<script src="https://unpkg.com/filepond-plugin-image-resize/dist/filepond-plugin-image-resize.js"></script>
<script src="https://unpkg.com/filepond-plugin-image-transform/dist/filepond-plugin-image-transform.js"></script>
<script src="https://unpkg.com/filepond-plugin-image-exif-orientation/dist/filepond-plugin-image-exif-orientation.js"></script>
<script src="{{asset('assets/plugins/filepond/filepond.js')}}"></script>

@livewireScripts

<script>
	// FilePond initialization
	document.addEventListener("DOMContentLoaded", function() {
		const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';

		// Fix PerfectScrollbar initialization error
		try {
			if (typeof PerfectScrollbar !== 'undefined') {
				const scrollElement = document.querySelector('.perfect-scrollbar');
				if (scrollElement) new PerfectScrollbar(scrollElement);
			}
		} catch (e) { /* ignore */ }

		// Initialize FilePond instances
		const filePondInstances = ['licenseBusiness', 'stampBusiness', 'licenseGarage', 'stampGarage', 'licenseShop', 'stampShop', 'audio', 'video'];
		filePondInstances.forEach(id => {
			const element = document.querySelector(`#${id}`);
			if (element) {
				FilePond.create(element).setOptions({
					allowMultiple: true,
					credits: false,
					imageResizeMode: 'contain',
					imagePreviewMaxFileSize: '3MB',
					acceptedFileTypes: id === 'audio' || id === 'video' ? null : ['image/*'],
					server: {
						process: `/upload/${id === 'audio' ? 'audio' : id === 'video' ? 'video' : 'image'}`,
						revert: '/delete',
						headers: { 'X-CSRF-TOKEN': csrfToken }
					}
				});
			}
		});

		// Image uploadify initialization
		const imageUploadify = document.getElementById('image-uploadify');
		if (imageUploadify && typeof $.fn.imageuploadify !== 'undefined') {
			$(imageUploadify).imageuploadify();
		}
	});

	// Remaining time countdown for Etera-Chereta proformas
	function updateRemainingTime() {
		document.querySelectorAll('[data-remaining-time]').forEach(element => {
			const expiresAt = element.getAttribute('data-remaining-time');
			if (!expiresAt) return;
			const now = new Date();
			const expiry = new Date(expiresAt);

			if (expiry > now) {
				const diff = Math.floor((expiry - now) / 1000);
				const hours = Math.floor(diff / 3600);
				const minutes = Math.floor((diff % 3600) / 60);
				element.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;

				if (diff < 3600) { element.classList.remove('bg-primary'); element.classList.add('bg-warning'); }
				if (diff < 900) { element.classList.remove('bg-warning'); element.classList.add('bg-danger'); }
			} else {
				element.textContent = 'Expired';
				element.classList.remove('bg-primary', 'bg-warning');
				element.classList.add('bg-secondary');
			}
		});
	}

	setInterval(updateRemainingTime, 60000);
	document.addEventListener('DOMContentLoaded', function() {
		updateRemainingTime();

		// Initialize tooltips
		var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
		tooltipTriggerList.map(function (tooltipTriggerEl) { return new bootstrap.Tooltip(tooltipTriggerEl); });

		// Auto-dismiss success flash messages after 5 seconds
		const alerts = document.querySelectorAll('.alert.alert-success');
		if (alerts.length > 0) {
			setTimeout(() => {
				alerts.forEach(el => {
					el.style.transition = 'opacity .4s ease';
					el.style.opacity = '0';
					setTimeout(() => el.remove(), 400);
				});
			}, 5000);
		}
	});

	// Google Autocomplete
	function initAutocomplete() {
		try {
			var options = { types: ['(cities)'] };
			var input = document.getElementById('autocomplete-input');
			if (!input) return;
			var autocomplete = new google.maps.places.Autocomplete(input, options);
		} catch (e) { /* ignore */ }
	}

	document.addEventListener('DOMContentLoaded', function() {
		const introBanner = document.querySelector('.intro-banner-search-form');
		if (introBanner) {
			setTimeout(function(){ $(".pac-container").prependTo(".intro-search-field.with-autocomplete"); }, 300);
		}
	});
</script>

<!-- Google API -->
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAaoOT9ioUE4SA8h-anaFyU4K63a7H-7bc&libraries=places&callback=initAutocomplete&loading=async"></script>

<!-- Auto-Logout after 30 minutes inactivity -->
<script>
(function() {
    var IDLE_TIMEOUT = 30 * 60 * 1000;
    var idleTimer;
    function resetTimer() {
        clearTimeout(idleTimer);
        idleTimer = setTimeout(logoutUser, IDLE_TIMEOUT);
    }
    function logoutUser() {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = '/logout';
        form.innerHTML = '<input type="hidden" name="_method" value="DELETE">' +
                         '<input type="hidden" name="_token" value="' +
                         (document.querySelector('meta[name="csrf-token"]')?.content || '{{ csrf_token() }}') + '">';
        document.body.appendChild(form);
        form.submit();
    }
    ['mousemove', 'mousedown', 'keypress', 'scroll', 'touchstart', 'click'].forEach(function(evt) {
        document.addEventListener(evt, resetTimer, { passive: true });
    });
    resetTimer();
})();
</script>

</body>
</html>
