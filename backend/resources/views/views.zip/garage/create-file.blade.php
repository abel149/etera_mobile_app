@extends('layouts.sparepart')
@section('content')

<div class="container margin-top-45 margin-bottom-45">
    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-10">
            <div class="dashboard-box">
                <div class="headline">
                    <h3><i class="icon-line-awesome-file-text"></i> Create Garage File</h3>
                </div>
                <div class="content with-padding">
                    <form method="POST" action="{{ route('garage.create-file') }}" enctype="multipart/form-data">
                        @csrf
                        <div class="row">
                            <div class="col-xl-6">
                                <div class="submit-field">
                                    <h5>File Type</h5>
                                    <select class="with-border" id="fileType" name="fileType" required>
                                        <option value="">Select Type</option>
                                        <option value="report">Report</option>
                                        <option value="invoice">Invoice</option>
                                        <option value="estimate">Estimate</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="submit-field">
                                    <h5>Time (HH:MM)</h5>
                                    <input type="time" class="with-border" id="time" name="time" required>
                                </div>
                            </div>
                            <div class="col-xl-12">
                                <div class="submit-field">
                                    <h5>Upload File</h5>
                                    <input class="with-border" type="file" id="file" name="file" required style="padding: 10px;">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="button ripple-effect big margin-top-30">
                            <i class="icon-feather-upload-cloud"></i> Request Proforma
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
