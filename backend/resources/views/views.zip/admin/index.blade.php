@extends('layouts.admin')
@section('content')
<!--start page wrapper -->
<div class="page-wrapper">
	<div class="page-content">
		    <div class="row">
		    <div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Proformas from Insurances</p>
								<h5 class="mb-0">{{\App\Models\Proforma::fromInsurances()->count()}}</h5>
							</div>
							<div id="chart4"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Completed Proformas from Insurances</p>
								<h5 class="mb-0">{{\App\Models\Proforma::fromInsurances()->where('status', 'completed')->count()}}</h5>
							</div>
							<div id="chart4"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Proformas from Others</p>
								<h5 class="mb-0">{{\App\Models\Proforma::fromOthers()->count()}}</h5>
							</div>
							<div id="chart4"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Completed Proformas from Others</p>
								<h5 class="mb-0">{{\App\Models\Proforma::fromOthers()->where('status', 'completed')->count()}}</h5>
							</div>
							<div id="chart4"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Users</p>
								<h5 class="mb-0">{{\App\Models\User::count()}}</h5>
							</div>
							<div id="chart1"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Admins</p>
								<h5 class="mb-0">{{\App\Models\User::where('role','admin')->count()}}</h5>
							</div>
							<div id="chart2"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Operators</p>
								<h5 class="mb-0">{{\App\Models\User::where('role','employee')->count()}}</h5>
							</div>
							<div id="chart1"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Insurances</p>
								<h5 class="mb-0">{{\App\Models\User::where('role','insurance')->count()}}</h5>
							</div>
							<div id="chart2"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Business Owners</p>
								<h5 class="mb-0">{{\App\Models\User::where('role','business_owner')->count()}}</h5>
							</div>
							<div id="chart1"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Marketers</p>
								<h5 class="mb-0">{{\App\Models\User::where('role','marketer')->count()}}</h5>
							</div>
							<div id="chart2"></div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Garages</p>
								<h5 class="mb-0">{{\App\Models\User::where('role','garage')->count()}}</h5>
							</div>
							<div id="chart3"></div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-12 col-md-4 col-sm-6 col-lg-4">
				<div class="card radius-10">
					<div class="card-body">
						<div class="d-flex align-items-center justify-content-between">
							<div>
								<p class="mb-0">Total Sparepart Shops</p>
								<h5 class="mb-0">{{\App\Models\User::where('role','shop')->count()}}</h5>
							</div>
							<div id="chart4"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--end row-->

		<!--end row-->
		<div class="card radius-10">
			<div class="card-body">
				<div class="table-responsive lead-table">
					<table class="table mb-0 align-middle">
						<thead class="table-light">
							<tr>
								<th>File #</th>
								<th>From</th>
								<th>Customer Name</th>
								<th>Garage Proforma</th>
								<th>Sparepart Proforma</th>
								<th>Status</th>
								<th>
									Remaining Time
									<i class="bx bx-info-circle ms-1" 
									   data-bs-toggle="tooltip" 
									   data-bs-placement="top" 
									   title="Shows remaining time for Etera-Chereta proformas (HH:MM format)"></i>
								</th>
								<th>Created At</th>
							</tr>
						</thead>
											@php
												$allProformas = \App\Models\Proforma::with('poster')->whereHas('poster')->orderBy('created_at', 'desc')->get();
											@endphp
						<tbody>
						@foreach($allProformas as $proforma)
							@php try { @endphp
							<tr>
								<td>{{$proforma->file_number ?? 'N/A'}}</td>
                        @php
                          $label = $proforma->poster ? ($proforma->poster->role == 'business_owner' ? 'Business Owner' : ucfirst($proforma->poster->role)) : 'Unknown';
                        @endphp
								<td>{{$label}}</td>
								<td>
									<div class="d-flex align-items-center">
											<h6 class="mb-0 font-14">{{$proforma->customer_name ?? 'N/A'}}</h6>
									</div>
								</td>
                                @if($proforma->poster && $proforma->isFromOthers())
                                    <td>N/A</td>
                                @else
                					<td>{{$proforma->applicationsFromGarages ? $proforma->applicationsFromGarages->count() : 0}} Garages Applied</td>
                                @endif
                					<td>{{$proforma->applicationsFromShops ? $proforma->applicationsFromShops->count() : 0}} Shops Applied</td>
                								<td>
                                @if($proforma->status == 'completed')
               								<div class="badge rounded-pill bg-secondary w-100">{{ucfirst($proforma->status)}}</div>
               						@elseif($proforma->status == 'published')
                                <div class="badge rounded-pill bg-info w-100">{{ucfirst($proforma->status)}}</div>
                                @elseif($proforma->status == 'pending' || $proforma->status == 'opened')
                                <div class="badge rounded-pill bg-warning w-100">{{($proforma->selected() && $proforma->status == 'pending') ? "File Assigned" : ucfirst($proforma->status)}}</div>
                                @elseif($proforma->status == 'closed')
                                <div class="badge rounded-pill bg-danger w-100">{{ucfirst($proforma->status)}}</div>
                                @elseif($proforma->status == 'rejected')
                                <div class="badge rounded-pill bg-danger w-100">{{ucfirst($proforma->status)}}</div>
                                @endif
                								</td>
								<td>
									@if($proforma->isEteraCheretaMode())
										<span class="badge rounded-pill bg-primary w-100" 
											  data-remaining-time="{{ $proforma->timer_expires_at?->toISOString() }}">
											{{ $proforma->getFormattedRemainingTime() }}
										</span>
									@else
										<span class="text-muted">N/A</span>
									@endif
								</td>
                                <td>{{$proforma->created_at ? $proforma->created_at->format('D M d, Y h:i A') : 'N/A'}}</td>
             						</tr>
							@php } catch (Exception $e) { /* skip */ } @endphp
                            @endforeach
										</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--end page wrapper -->

@endsection
